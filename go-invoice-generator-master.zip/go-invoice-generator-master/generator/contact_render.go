package generator

import (
	"bytes"
	b64 "encoding/base64"
	"image"

	"codeberg.org/go-pdf/fpdf"
)

func (c *Contact) appendContactTODoc(x, y float64, fill bool, logoAlign string, doc *Document) float64 {
	doc.pdf.SetXY(x, y)

	if c.Logo != nil {
		fileName := b64.StdEncoding.EncodeToString([]byte(c.Name))
		ioReader := bytes.NewReader(c.Logo)
		_, format, _ := image.DecodeConfig(bytes.NewReader(c.Logo))

		imageInfo := doc.pdf.RegisterImageOptionsReader(fileName, fpdf.ImageOptions{
			ImageType: format,
		}, ioReader)

		if imageInfo != nil {
			var imageOpt fpdf.ImageOptions
			imageOpt.ImageType = format
			doc.pdf.ImageOptions(fileName, doc.pdf.GetX(), y, 0, 30, false, imageOpt, 0, "")
			doc.pdf.SetY(y + 30)
		}
	}

	if fill {
		doc.pdf.SetFillColor(doc.Options.GreyBgColor[0], doc.Options.GreyBgColor[1], doc.Options.GreyBgColor[2])
	} else {
		doc.pdf.SetFillColor(255, 255, 255)
	}

	doc.pdf.SetX(x)
	doc.pdf.Rect(x, doc.pdf.GetY(), 70, 8, "F")
	doc.pdf.SetFont(doc.Options.BoldFont, "B", 10)
	doc.pdf.Cell(40, 8, doc.encodeString(c.Name))
	doc.pdf.SetFont(doc.Options.Font, "", 10)

	if c.Address != nil {
		var addrRectHeight float64 = 17
		if len(c.Address.Address2) > 0 {
			addrRectHeight += 5
		}
		if len(c.Address.Country) == 0 {
			addrRectHeight -= 5
		}
		doc.pdf.Rect(x, doc.pdf.GetY()+9, 70, addrRectHeight, "F")
		doc.pdf.SetFont(doc.Options.Font, "", 10)
		doc.pdf.SetXY(x, doc.pdf.GetY()+10)
		doc.pdf.MultiCell(70, 5, doc.encodeString(c.Address.ToString()), "0", "L", false)
	}

	if c.AddtionnalInfo != nil {
		doc.pdf.SetXY(x, doc.pdf.GetY())
		doc.pdf.SetFontSize(SmallTextFontSize)
		doc.pdf.SetXY(x, doc.pdf.GetY()+2)
		for _, line := range c.AddtionnalInfo {
			doc.pdf.SetXY(x, doc.pdf.GetY())
			doc.pdf.MultiCell(70, 3, doc.encodeString(line), "0", "L", false)
		}
		doc.pdf.SetXY(x, doc.pdf.GetY())
		doc.pdf.SetFontSize(BaseTextFontSize)
	}

	return doc.pdf.GetY()
}

func (c *Contact) appendCompanyContactToDoc(doc *Document) float64 {
	x, y, _, _ := doc.pdf.GetMargins()
	return c.appendContactTODoc(x, y, true, "L", doc)
}

func (c *Contact) appendCustomerContactToDoc(doc *Document) float64 {
	return c.appendContactTODoc(130, BaseMarginTop+25, true, "R", doc)
}
